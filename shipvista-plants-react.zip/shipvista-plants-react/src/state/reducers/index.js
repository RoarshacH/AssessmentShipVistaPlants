import { combineReducers } from "redux";
import { plantReducer } from "./plantReducers";

export const reducers = combineReducers({
  plantReducer,
});
